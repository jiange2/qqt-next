<?php
	$app_lang = array();

	// for invalid email format
	$app_lang['invalid_email_format']="Email format is invalid !";

	// for otp sent
	$app_lang['otp_sent']="OTP has been sent on your mail...";

	// for email not found
	$app_lang['email_not_found']="Email is not found !";

	// for invalid password
	$app_lang['invalid_password']="Password is invalid !";

	// for account deactive
	$app_lang['account_deactive']="Sorry ! Your account is suspended";

	// for lagin success
	$app_lang['login_success']="Login successfully...";

	// for lagin failed
	$app_lang['login_fail']="Login is failed !";

	// for email exist
	$app_lang['email_exist']="Email is already exist !";

	// for register success
	$app_lang['register_success']="Registration successfully...";

	// for register failed
	$app_lang['register_fail']="Registration is failed !";

	// for comment success
	$app_lang['comment_success']="Comment submitted successfully...";

	// for comment failed
	$app_lang['comment_fail']="Comment is failed";

	// for comment delete
	$app_lang['comment_delete']="Comment is deleted...";

	// for report success
	$app_lang['report_success']="Report submitted successfully...";

	// for report failed
	$app_lang['report_fail']="Report is failed";

	// for report already submitted
	$app_lang['report_already']="Report already submitted !";

	// for search not found
	$app_lang['search_result']="Keyword is not found ! Try different keyword";

	// for password send in mail
	$app_lang['password_sent_mail']="Password has been sent on your mail...";	

	// for added success
	$app_lang['add_success']="Added successfully...";

	// for added failed
	$app_lang['add_fail']="Adding is failed !";

	// for updated success
	$app_lang['update_success']="Updated successfully...";

	// for updated failed
	$app_lang['update_fail']="Updatation is failed !";

	// for message sent
	$app_lang['msg_sent']="Message has been sent...";

	// rating messages
	$app_lang['rate_success']="You have successfully rated";
	$app_lang['rate_already']="You have already rated !";

	// suggest messages
	$app_lang['suggest_success']="You have successfully submitted your suggestion, it will be reviewed by admin and will uploaded if necessary";


	// for favourite
	$app_lang['favourite_success']="Added to Favourite";

	// for favourite remove
	$app_lang['favourite_remove_success']="Removed from Favourite";

	// for favourite remove error
	$app_lang['favourite_remove_error']="Error in remove from Favourite";

	// for no data
	$app_lang['no_data_msg']="Sorry no data found !";
	
	// All kind of email template label

	// for email dear label
	$app_lang['dear_lbl']="Dear";

	// for email your password label
	$app_lang['your_password_lbl']="Your Password is";

	// for registration email subject
	$app_lang['register_mail_lbl']="[IMPORTANT] ### Registration completed";  // don't remove ### that will be replaced by you app name

	// for reporter request approve mail subject
	$app_lang['reporter_sub_lbl']="[IMPORTANT] ### Reporter Information";  // don't remove ### that will be replaced by you app name

	// for reporter request message
	$app_lang['reporter_req_msg']="你的举报请求已被批准";

	// for reporter request message new line
	$app_lang['reporter_req_msg2']="你可以从管理面板上面访问: ";

	// for forgot password email subject
	$app_lang['forgot_password_sub_lbl']="[IMPORTANT] ### 忘记密码信息";  // don't remove ### that will be replaced by you app name

	// for email copyright label
	$app_lang['welcome_lbl']="欢迎你";

	// for google registration success message
	$app_lang['google_register_msg']="You have successfully registration with google";

	// for facebook registration success message
	$app_lang['facebook_register_msg']="You have successfully registration with facebook";

	// for normal registration success message
	$app_lang['normal_register_msg']="你的注册成功完成";

	// for thank you
	$app_lang['thank_you_lbl']="非常感谢你";

	// for email copyright label
	$app_lang['email_copyright']="Copyright ©";

?>